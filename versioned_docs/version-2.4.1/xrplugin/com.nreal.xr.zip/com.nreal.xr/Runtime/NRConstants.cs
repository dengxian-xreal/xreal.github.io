﻿/****************************************************************************
* Copyright 2019 Xreal Techonology Limited. All rights reserved.
*                                                                                                                                                          
* This file is part of NRSDK.                                                                                                          
*                                                                                                                                                           
* https://www.xreal.com/        
* 
*****************************************************************************/

namespace Unity.XR.NRSDK
{
    public static class NRConstants
    {
        /// <summary>
        /// Key we use to store and retrieve custom configuration settings from EditorBuildSettings
        /// </summary>
        public const string k_SettingsKey = "com.unity.xr.management.nrsettings";
    }
}
